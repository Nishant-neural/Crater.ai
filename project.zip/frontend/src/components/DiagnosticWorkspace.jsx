import { useEffect, useMemo, useState } from "react";
import { listMachines } from "../api/machines";
import { listRevisions } from "../api/revisions";
import { getRevisionIngestionStatus } from "../api/client";
import { startDiagnostic, getDiagnostic, getDiagnosticContext, respondDiagnostic,
  recordDiagnosticOutcome, getMostInformativeTest, getGuidedPhysicalChecks } from "../api/diagnostics";
import MachineOnboarding from "./MachineOnboarding";

function Card({title, children, className=""}) {
  return <section className={`diag-card ${className}`}><div className="diag-card__title">{title}</div>{children}</section>;
}

function StatusPill({children, tone=""}) { return <span className={`status-pill ${tone}`}>{children}</span>; }

function MachineGraph({components, relationships, focus}) {
  const nodes = useMemo(() => components.slice(0, 18), [components]);
  if (!nodes.length) return <div className="empty-state">No component topology is available for this revision.</div>;
  const width = 620, height = Math.max(250, Math.ceil(nodes.length / 4) * 100);
  const pos = Object.fromEntries(nodes.map((n,i) => [n.id, {x: 80+(i%4)*150, y: 55+Math.floor(i/4)*95}]));
  return <div className="machine-graph">
    <svg viewBox={`0 0 ${width} ${height}`} role="img" aria-label="Machine relationship graph">
      {relationships.map(r => {
        const a=pos[r.from], b=pos[r.to]; if(!a||!b) return null;
        return <g key={r.id}><line x1={a.x} y1={a.y} x2={b.x} y2={b.y} className="graph-edge"/>
          <text x={(a.x+b.x)/2} y={(a.y+b.y)/2-5} className="graph-edge-label">{r.type}</text></g>
      })}
      {nodes.map(n => <g key={n.id} className={focus && n.name.toLowerCase().includes(focus.toLowerCase()) ? "graph-node graph-node--focus" : "graph-node"}>
        <rect x={pos[n.id].x-55} y={pos[n.id].y-24} width="110" height="48" rx="10"/>
        <text x={pos[n.id].x} y={pos[n.id].y+4} textAnchor="middle">{n.name.slice(0,18)}</text>
      </g>)}
    </svg>
  </div>;
}

export default function DiagnosticWorkspace({ onMachineReady }) {
  const [machines,setMachines]=useState([]);
  const [revisions,setRevisions]=useState([]);
  const [productId,setProductId]=useState("");
  const [revisionId,setRevisionId]=useState("");
  const [symptom,setSymptom]=useState("Motor M1 is overheating after 20 minutes.");
  const [session,setSession]=useState(null);
  const [context,setContext]=useState(null);
  const [answer,setAnswer]=useState("");
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState("");
  const [selectedEvidence,setSelectedEvidence]=useState(null);
  const [showOnboarding,setShowOnboarding]=useState(false);
  const [revisionIngestion,setRevisionIngestion]=useState(null);
  const [outcomeForm,setOutcomeForm]=useState({outcome:"fixed",confirmed_cause:"",repair_performed:"",technician_notes:"",submit_correction_for_review:false});
  const [outcomeResult,setOutcomeResult]=useState(null);
  const [nextTest,setNextTest]=useState(null);
  const [guidedChecks,setGuidedChecks]=useState(null);
  const [feedbackBusy,setFeedbackBusy]=useState(false);

  async function loadMachines(selectProductId = null, selectRevisionId = null) {
    try {
      const rows = (await listMachines()) || [];
      setMachines(rows);

      if (selectProductId) {
        setProductId(selectProductId);
      } else if (!productId && rows.length) {
        setProductId(rows[0].id);
      }

      if (selectRevisionId) {
        setRevisionId(selectRevisionId);
      }
    } catch (e) {
      setError(e.message || "Unable to load machines.");
    }
  }
  useEffect(()=>{ loadMachines(); },[]);
  useEffect(()=>{
    if(!productId){
      setRevisions([]);
      setRevisionId("");
      return;
    }
    listRevisions(productId)
      .then(rows=>{
        const next = rows || [];
        setRevisions(next);
        setRevisionId(current =>
          current && next.some(row => row.id === current)
            ? current
            : (next[0]?.id || "")
        );
      })
      .catch(e=>setError(e.message || "Unable to load revisions."));
  },[productId]);

  useEffect(()=>{
    if(!revisionId){ setRevisionIngestion(null); return; }
    getRevisionIngestionStatus(revisionId)
      .then(setRevisionIngestion)
      .catch(e=>setRevisionIngestion({status:"unknown",error:e.message}));
  },[revisionId]);

  async function begin(){
    if(!productId||!revisionId||!symptom.trim()) return;
    setBusy(true);setError("");
    try {
      const s=await startDiagnostic({product_id:productId,revision_id:revisionId,symptom:symptom.trim()});
      setSession(s);
      setContext(await getDiagnosticContext(s.session_id));
    } catch(e){setError(e.message)} finally{setBusy(false)}
  }
  async function sendAnswer(value=answer){
    if(!session||!value.trim()) return;
    setBusy(true);setError("");
    try {
      const s=await respondDiagnostic(session.session_id,{input:value.trim(),input_kind:"observation"});
      setSession(s);setAnswer("");
      if(!context) setContext(await getDiagnosticContext(s.session_id));
    } catch(e){setError(e.message)} finally{setBusy(false)}
  }
  async function refresh(){
    if(!session) return;
    try { setSession(await getDiagnostic(session.session_id)); setContext(await getDiagnosticContext(session.session_id)); }
    catch(e){setError(e.message)}
  }

  async function loadNextTest(){
    if(!session) return;
    setFeedbackBusy(true); setError("");
    try { setNextTest(await getMostInformativeTest(session.session_id)); }
    catch(e){setError(e.message)} finally{setFeedbackBusy(false)}
  }
  async function loadGuidedChecks(){
    if(!session) return;
    setFeedbackBusy(true); setError("");
    try { setGuidedChecks(await getGuidedPhysicalChecks(session.session_id)); }
    catch(e){setError(e.message)} finally{setFeedbackBusy(false)}
  }
  async function submitOutcome(){
    if(!session) return;
    setFeedbackBusy(true); setError("");
    try { setOutcomeResult(await recordDiagnosticOutcome(session.session_id, outcomeForm)); }
    catch(e){setError(e.message)} finally{setFeedbackBusy(false)}
  }

  const state=session?.state;
  const step=state?.current_step;
  const leading=state?.hypotheses?.[0];
  const isQuestion=step?.type==="question";
  const isConclusion=step?.type==="conclusion";
  const machine=context?.product;
  const revision=context?.revision;
  const docs=context?.documents||[];
  const evidence=state?.evidence||[];

  if(!session) return <div className="diagnostic">
    {showOnboarding && <MachineOnboarding
      initialProductId={productId}
      initialRevisionId={revisionId}
      onCancel={()=>setShowOnboarding(false)}
      onReady={async ({productId: readyProductId, revisionId: readyRevisionId, knowledgeWarning})=>{
        setShowOnboarding(false);
        setError(knowledgeWarning || "");
        await loadMachines(readyProductId, readyRevisionId);
        onMachineReady?.({ productId: readyProductId, revisionId: readyRevisionId });
      }}
    />}
    <div className="diag-hero">
      <div>
        <div className="eyebrow">PHASE 9 · DIAGNOSTIC WORKSTATION</div>
        <h2>Investigate a machine failure.</h2>
        <p>Move from symptom → evidence → hypotheses → targeted question → repair, without turning the product into a generic chatbot.</p>
      </div>
      <div className="hero-flow"><span>Machine</span><b>→</b><span>Evidence</span><b>→</b><span>Diagnosis</span><b>→</b><span>Repair</span></div>
    </div>
    <div className="setup-grid">
      <Card title="1 · Machine">
        {machines.length > 0 ? <>
          <label>Product
            <select value={productId} onChange={e=>setProductId(e.target.value)}>
              <option value="">Select machine</option>
              {machines.map(m=><option key={m.id} value={m.id}>{m.manufacturer} · {m.family} · {m.model}</option>)}
            </select>
          </label>
          <label>Revision
            <select value={revisionId} onChange={e=>setRevisionId(e.target.value)} disabled={!productId}>
              <option value="">Select revision</option>
              {revisions.map(r=><option key={r.id} value={r.id}>{r.label}</option>)}
            </select>
          </label>
          {revisionId && revisionIngestion?.status === "ready" && <div className="ready-check"><StatusPill tone="ok">READY</StatusPill> {revisionIngestion.document_count} manual(s) ingested{revisionIngestion.active_count ? " · another manual is processing" : ""}</div>}
          {revisionId && revisionIngestion?.status === "processing" && <div className="ready-check"><StatusPill tone="live">INGESTING</StatusPill> {revisionIngestion.completed_count} completed manual(s) · {revisionIngestion.active_count} still processing</div>}
          {revisionId && revisionIngestion?.status === "failed" && <div className="ready-check"><StatusPill tone="warn">INGESTION FAILED</StatusPill> No completed manual is available yet. Open onboarding to retry from the checkpoint.</div>}
          <button className="secondary-button full-width" onClick={()=>setShowOnboarding(true)}>+ Add manual to this revision</button>
        </> : <div className="onboarding-empty">
          <div className="empty-icon">＋</div>
          <h3>No machines onboarded</h3>
          <p>Start by uploading a machine manual. Crater will create the machine, revision, extract knowledge, and make it available here.</p>
          <button className="primary-button" onClick={()=>setShowOnboarding(true)}>Upload manual & onboard machine</button>
        </div>}
      </Card>
      <Card title="2 · Symptom">
        <label>What is happening with the machine?
          <textarea value={symptom} onChange={e=>setSymptom(e.target.value)} rows={5} placeholder="Describe the symptom..."/>
        </label>
        <button className="primary-button" disabled={busy||!productId||!revisionId||!symptom.trim()} onClick={begin}>
          {busy ? "Starting investigation…" : "Start investigation"}
        </button>
      </Card>
    </div>
    {error && <div className="diag-error">{error}</div>}
  </div>;

  return <div className="diagnostic diagnostic--session">
    <header className="diagnostic-header">
      <div>
        <div className="eyebrow">LIVE DIAGNOSTIC SESSION</div>
        <h2>{machine?.model || "Machine"} <span>/ {revision?.label || "Revision"}</span></h2>
      </div>
      <div className="header-actions"><StatusPill tone={session.status==="active"?"live":session.status==="concluded"?"ok":"warn"}>{session.status}</StatusPill><button onClick={refresh} disabled={busy}>Refresh</button></div>
    </header>
    {error && <div className="diag-error">{error}</div>}
    <div className="diagnostic-grid">
      <aside className="diagnostic-left">
        <Card title="MACHINE CONTEXT">
          <div className="context-stat"><b>{context?.knowledge?.entity_count ?? 0}</b><span>entities</span></div>
          <div className="context-stat"><b>{context?.knowledge?.relation_count ?? 0}</b><span>relationships</span></div>
          <div className="context-stat"><b>{context?.knowledge?.conflict_count ?? 0}</b><span>conflicts</span></div>
          <div className="context-docs"><b>Sources</b>{docs.slice(0,5).map(d=><span key={d.id}>{d.title}</span>)}</div>
        </Card>
        <Card title="MACHINE RELATIONSHIPS">
          <MachineGraph components={context?.components||[]} relationships={context?.relationships||[]} focus={leading?.cause}/>
        </Card>
        <Card title="INVESTIGATION TIMELINE">
          <div className="timeline">
            {(state?.timeline||[]).map((t,i)=><div className="timeline-item" key={i}><span>#{t.turn}</span><div><b>{t.kind}</b><p>{t.input}</p></div></div>)}
          </div>
        </Card>
      </aside>
      <main className="diagnostic-center">
        <Card title="SYMPTOM"><div className="symptom-box">{state?.symptoms?.[0] || symptom}</div></Card>
        <Card title={`HYPOTHESES · ${state?.hypotheses?.length||0}`}>
          <div className="hypothesis-list">
            {(state?.hypotheses||[]).map((h,i)=><article className={`hypothesis ${i===0?"hypothesis--leading":""}`} key={h.cause}>
              <div className="hypothesis-top"><div><span className="rank">{String(i+1).padStart(2,"0")}</span><b>{h.cause}</b></div><span>{Math.round(h.confidence*100)}%</span></div>
              <div className="confidence-track"><i style={{width:`${Math.max(0,Math.min(100,h.confidence*100))}%`}}/></div>
              <p>{h.rationale}</p>
              {h.supporting_evidence_chunk_ids?.length>0 && <div className="evidence-tags">{h.supporting_evidence_chunk_ids.map(id=><button key={id} onClick={()=>setSelectedEvidence(evidence.find(e=>e.chunk_id===id))}>Evidence {id.slice(0,8)}</button>)}</div>}
            </article>)}
            {!state?.hypotheses?.length && <div className="empty-state">The diagnostic agent has not produced a usable hypothesis yet.</div>}
          </div>
        </Card>
        <Card title="EVIDENCE">
          <div className="evidence-list">{evidence.map(e=><button className={`evidence-item ${selectedEvidence?.chunk_id===e.chunk_id?"selected":""}`} key={e.chunk_id} onClick={()=>setSelectedEvidence(e)}>
            <div><b>{e.source_document||"Source document"}</b><span>{e.page_number?`p.${e.page_number}`:"page unavailable"}</span></div>
            <p>{e.content}</p>
          </button>)}</div>
          {!evidence.length && <div className="empty-state">No source evidence was retrieved for this turn.</div>}
        </Card>
      </main>
      <aside className="diagnostic-right">
        <Card title="NEXT DIAGNOSTIC STEP" className="question-card">
          <StatusPill tone={isQuestion?"live":isConclusion?"ok":"warn"}>{step?.type || "waiting"}</StatusPill>
          <h3>{step?.content || "No next step is available."}</h3>
          {step?.rationale && <p className="muted">{step.rationale}</p>}
          {step?.safety_notes?.length>0 && <div className="safety-box"><b>Safety notes</b>{step.safety_notes.map((x,i)=><span key={i}>{x}</span>)}</div>}
          {isQuestion && <div className="answer-actions">
            <button onClick={()=>sendAnswer("Yes")}>YES</button><button onClick={()=>sendAnswer("No")}>NO</button><button onClick={()=>sendAnswer("Not sure")}>NOT SURE</button>
            <div className="answer-input"><input value={answer} onChange={e=>setAnswer(e.target.value)} onKeyDown={e=>e.key==="Enter"&&sendAnswer()} placeholder="Or enter an observation…"/><button onClick={()=>sendAnswer()} disabled={!answer.trim()||busy}>Send</button></div>
          </div>}
          {step?.type==="action" && <div className="answer-input"><input value={answer} onChange={e=>setAnswer(e.target.value)} placeholder="Enter the measurement / result…"/><button onClick={()=>sendAnswer()} disabled={!answer.trim()||busy}>Submit</button></div>}
        </Card>
        <Card title="REPAIR / RECOMMENDATION">
          {isConclusion ? <div className="repair">
            <StatusPill tone="ok">RECOMMENDATION READY</StatusPill>
            <h3>{step.content}</h3>
            <p>{step.rationale || "Grounded in the evidence shown in this session."}</p>
            {evidence.slice(0,4).map(e=><div className="repair-source" key={e.chunk_id}>↳ {e.source_document}{e.page_number?` · p.${e.page_number}`:""}</div>)}
          </div> : <div className="empty-state">A structured repair recommendation will appear after the diagnostic state reaches a grounded conclusion.</div>}
        </Card>
        <Card title="MOST INFORMATIVE NEXT TEST">
          <p className="muted">Ranks documented tests that may separate the leading hypotheses. This is a heuristic, not calculated probabilistic information gain.</p>
          <button onClick={loadNextTest} disabled={feedbackBusy}>{feedbackBusy ? "Working…" : "Find discriminating test"}</button>
          {nextTest && (nextTest.tests?.length ? nextTest.tests.map((t,i)=><article className="guided-check" key={`${t.test}-${i}`}>
            <b>{i+1}. {t.test}</b>
            {t.expected_observation && <p>Expected observation: {t.expected_observation}</p>}
            <small>May distinguish: {t.matched_hypotheses?.join(", ") || "not mapped to a current hypothesis"}</small>
          </article>) : <p className="muted">{nextTest.reason || "No documented discriminating test found."}</p>)}
        </Card>
        <Card title="GUIDED PHYSICAL CHECKS">
          <p className="muted">Only documented tests are presented. Verify the exact machine, connector and safety procedure before touching hardware.</p>
          <button onClick={loadGuidedChecks} disabled={feedbackBusy}>{feedbackBusy ? "Working…" : "Prepare physical checks"}</button>
          {guidedChecks?.checks?.map((c,i)=><article className="guided-check" key={`${c.instruction}-${i}`}>
            <b>{i+1}. {c.instruction}</b>
            {c.expected_observation && <p>Expected: {c.expected_observation}</p>}
            {c.candidate_schematic_labels?.length>0 && <p>Candidate schematic labels: {c.candidate_schematic_labels.join(", ")} (not verified pin mapping)</p>}
            <small>{c.safety_note}</small><p className="muted">{c.limits}</p>
          </article>)}
          {guidedChecks && !guidedChecks.checks?.length && <p className="muted">{guidedChecks.message} No stored documented test matched the current hypotheses.</p>}
        </Card>
        <Card title="DID THE REPAIR WORK?">
          {outcomeResult ? <div className="ready-check"><StatusPill tone="ok">RECORDED</StatusPill> Outcome saved · {outcomeResult.review_status}{outcomeResult.knowledge_version_id ? <p>Draft knowledge version: {outcomeResult.knowledge_version_id}. Review and approve it in Expert Knowledge before it influences diagnosis.</p> : null}</div> : <>
            <label>Repair outcome<select value={outcomeForm.outcome} onChange={e=>setOutcomeForm(v=>({...v,outcome:e.target.value}))}>
              <option value="fixed">Fixed</option><option value="not_fixed">Not fixed</option><option value="inconclusive">Inconclusive / not yet verified</option>
            </select></label>
            <label>Confirmed cause / correction<input value={outcomeForm.confirmed_cause} onChange={e=>setOutcomeForm(v=>({...v,confirmed_cause:e.target.value}))} placeholder="What was actually wrong?"/></label>
            <label>Repair performed<input value={outcomeForm.repair_performed} onChange={e=>setOutcomeForm(v=>({...v,repair_performed:e.target.value}))} placeholder="What did the technician change?"/></label>
            <label>Notes<textarea rows={2} value={outcomeForm.technician_notes} onChange={e=>setOutcomeForm(v=>({...v,technician_notes:e.target.value}))} placeholder="What happened after repair?"/></label>
            <label className="feedback-checkbox"><input type="checkbox" checked={outcomeForm.submit_correction_for_review} onChange={e=>setOutcomeForm(v=>({...v,submit_correction_for_review:e.target.checked}))}/> Submit correction as draft expert knowledge for review</label>
            <button onClick={submitOutcome} disabled={feedbackBusy}>{feedbackBusy ? "Saving…" : "Save repair outcome"}</button>
          </>}
        </Card>
        <Card title="VERIFICATION">
          <div className="verification-unavailable"><b>Simulation contract</b><p>Verification is only marked PASS/FAIL when a real digital-twin experiment is executed. No simulated success is shown here.</p><button onClick={()=>window.dispatchEvent(new CustomEvent("crater-open-simulation", {detail:{revisionId, sessionId:session?.session_id, hypothesis:leading?.cause || ""}}))}>Open simulation workspace</button></div>
        </Card>
      </aside>
    </div>
  </div>;
}
