"""LLM-based structured extraction for large semantic manual chunks.

Chunks are deliberately larger and may span pages so the model can see the
context needed to extract useful components, specifications, relationships,
and procedures. Each result is still persisted against one source chunk, so
provenance remains exact at the chunk/page-range level.
"""
from __future__ import annotations

import json

from sqlalchemy.orm import Session

from backend.db.models import (
    Component,
    ComponentRelationship,
    MachineKnowledgeBehavior,
    MachineKnowledgeEntity,
    MachineKnowledgeEvidence,
    MachineKnowledgeFact,
    MachineKnowledgeRelation,
    Procedure,
    RelationType,
    ProcedureType,
)
from backend.knowledge.evidence import MachineEvidence
from backend.knowledge.normalization import normalize_payload
from backend.knowledge.machine_model import (
    MachineBehavior,
    MachineConstraint,
    MachineEntity,
    MachineEvent,
    MachineRelation,
    MachinePort,
    MachineQuantity,
    MachineState,
    UniversalMachineModel,
)
from backend.knowledge.schema import ExtractionResult, MachineKnowledgeExtractionResult
from backend.llm import gateway
from backend.config import settings


class ExtractionError(RuntimeError):
    """Extraction failure with retry guidance for the ingestion scheduler."""

    def __init__(self, message: str, *, retryable: bool = False, rate_limited: bool = False):
        super().__init__(message)
        self.retryable = retryable
        self.rate_limited = rate_limited


_EXTRACTION_PROMPT = """You are extracting structured technical knowledge from a technical excerpt of an \
industrial equipment manual. The excerpt may span multiple pages. Only extract what is explicitly stated — do not infer or \
invent components, connections, or procedures that aren't clearly described in the text.

If the text contains no extractable technical knowledge (e.g. it's a cover page, \
table of contents, or legal boilerplate), return empty lists.

Text:
---
{content}
---

Respond with ONLY JSON matching this shape (omit fields that don't apply, use empty lists \
where nothing was found). Every extracted item must include an evidence object with fact, \
source_type, confidence from 0.0 to 1.0, claim_status (observed|inferred|uncertain), and extraction_method. Use status KNOWN, UNKNOWN, \
or UNCERTAIN when a value is not explicit:

{{
    "components": [{{"name": "", "function": "", "location_description": "", "part_number": "", "evidence": {{"fact": "", "source_type": "text", "confidence": 0.0, "extraction_method": "llm"}}}}],
    "relationships": [{{"from_component": "", "to_component": "", "relation_type": "electrical|mechanical|fluid|signal|contains", "description": "", "evidence": {{"fact": "", "source_type": "text", "confidence": 0.0, "extraction_method": "llm"}}}}],
    "procedures": [{{"name": "", "procedure_type": "installation|removal|calibration|maintenance|troubleshooting|replacement|verification", "steps": [""]}}],
    "entities": [{{"id": "entity:p1", "name": "", "entity_type": "", "properties": {{}}, "ports": [], "states": [], "evidence": []}}],
    "relations": [{{"subject_id": "", "subject_name": "", "relation_type": "", "object_id": "", "object_name": "", "description": "", "evidence": []}}],
    "ports": [{{"id": "port:p1", "entity_id": "", "name": "", "direction": "", "properties": {{}}, "evidence": []}}],
    "quantities": [{{"id": "quantity:q1", "entity_id": "", "name": "", "value": "", "unit": "", "properties": {{}}, "evidence": []}}],
    "states": [{{"entity_id": "", "name": "", "value": "", "properties": {{}}, "evidence": []}}],
    "events": [{{"id": "event:e1", "entity_id": "", "name": "", "description": "", "evidence": []}}],
    "behaviors": [{{"id": "behavior:b1", "subject_id": "", "subject_name": "", "description": "", "evidence": []}}],
    "constraints": [{{"id": "constraint:c1", "entity_id": "", "name": "", "description": "", "evidence": []}}]
}}"""


def _extract_result(content: str) -> MachineKnowledgeExtractionResult:
    try:
        raw = gateway.complete("extraction",
            messages=[{"role": "user", "content": _EXTRACTION_PROMPT.format(content=content)}],
            max_tokens=4000,
        )
    except Exception as exc:
        message = str(exc)
        lower = message.lower()
        rate_limited = any(token in lower for token in ("429", "resource_exhausted", "rate limit", "quota exceeded", "too many requests"))
        raise ExtractionError(
            f"LLM extraction request failed: {message}",
            retryable=True,
            rate_limited=rate_limited,
        ) from exc
    if not raw:
        raise ExtractionError("LLM returned no extraction output")
    text = raw.strip()
    if text.startswith("```"):
        import re
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        start, end = text.find("{"), text.rfind("}")
        if start < 0 or end <= start:
            raise ExtractionError("LLM returned invalid JSON")
        try:
            payload = json.loads(text[start:end + 1])
        except json.JSONDecodeError as exc:
            raise ExtractionError(f"LLM returned invalid JSON: {exc.msg}") from exc
    try:
        if not isinstance(payload, dict):
            raise ValueError("extraction root must be an object")
        # Apply one shared alias contract to every typed fact collection before validation.
        for key in ("components", "relationships", "procedures", "entities", "relations", "ports", "quantities", "states", "events", "behaviors", "constraints"):
            if isinstance(payload.get(key), list):
                payload[key] = [normalize_payload(item, kind=key[:-1] if key.endswith("s") else key) if isinstance(item, dict) else item for item in payload[key]]
        return MachineKnowledgeExtractionResult.model_validate(payload)
    except ValueError as exc:
        raise ExtractionError(f"LLM extraction schema validation failed: {exc}") from exc


_BATCH_EXTRACTION_PROMPT = """You are extracting structured technical knowledge from MULTIPLE independent excerpts of an industrial equipment manual.

Process every excerpt independently. Do not merge facts between excerpts and do not move a fact from one source_chunk_id to another.
Only extract what is explicitly stated. Do not infer or invent components, connections, or procedures.
If an excerpt contains no extractable technical knowledge, return empty lists for that excerpt.

Return ONLY JSON in this shape:
{{
  "chunks": [
    {
      "source_chunk_id": "the exact supplied id",
      "knowledge": {{
        "components": [], "relationships": [], "procedures": [],
        "entities": [], "relations": [], "evidence": [], "ports": [],
        "states": [], "quantities": [], "events": [], "behaviors": [], "constraints": []
      }
    }
  ]
}}

The knowledge object for each excerpt must use exactly the same field shapes as the single-excerpt extraction contract. Every supplied source_chunk_id must appear exactly once.

EXCERPTS:
__EXCERPTS__
"""


def _parse_json_response(raw: str) -> dict:
    if not raw:
        raise ExtractionError("LLM returned no extraction output")
    text = raw.strip()
    if text.startswith("```"):
        import re
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start, end = text.find("{"), text.rfind("}")
        if start < 0 or end <= start:
            raise ExtractionError("LLM returned invalid JSON")
        try:
            return json.loads(text[start:end + 1])
        except json.JSONDecodeError as exc:
            raise ExtractionError(f"LLM returned invalid JSON: {exc.msg}") from exc


def extract_chunk_knowledge_batch(chunks: list[tuple[str, str]]) -> dict[str, tuple[ExtractionResult, UniversalMachineModel]]:
    """Extract several independent chunks in one provider request.

    The result is keyed by source chunk ID. The batch contract is deliberately
    strict: missing or duplicate IDs cause an ExtractionError so the caller can
    retry with a smaller batch instead of silently losing provenance.
    """
    if not chunks:
        return {}
    if len(chunks) == 1:
        result, model = extract_chunk_knowledge(chunks[0][1])
        return {chunks[0][0]: (result, model)}

    excerpts = "\n\n".join(
        f"===== SOURCE_CHUNK_ID: {chunk_id} =====\n{content}\n===== END SOURCE_CHUNK_ID: {chunk_id} ====="
        for chunk_id, content in chunks
    )
    if len(excerpts) > settings.extraction_batch_max_chars:
        raise ExtractionError("Extraction batch exceeds configured character budget")

    try:
        raw = gateway.complete(
            "extraction",
            messages=[{"role": "user", "content": _BATCH_EXTRACTION_PROMPT.replace("__EXCERPTS__", excerpts)}],
            max_tokens=max(4000, min(16000, len(chunks) * 1000)),
        )
    except Exception as exc:
        message = str(exc)
        lower = message.lower()
        rate_limited = any(token in lower for token in ("429", "resource_exhausted", "rate limit", "quota exceeded", "too many requests"))
        raise ExtractionError(
            f"LLM batch extraction request failed: {message}",
            retryable=True,
            rate_limited=rate_limited,
        ) from exc

    try:
        payload = _parse_json_response(raw)
    except ExtractionError as exc:
        # A malformed/truncated batch response is usually caused by too much
        # output for the selected batch. The caller should split it immediately,
        # not spend two more RPM slots asking for the same malformed response.
        raise ExtractionError(str(exc), retryable=False) from exc
    rows = payload.get("chunks") if isinstance(payload, dict) else None
    if not isinstance(rows, list):
        raise ExtractionError("LLM batch extraction response missing chunks list")

    expected = [chunk_id for chunk_id, _ in chunks]
    seen: set[str] = set()
    out: dict[str, tuple[ExtractionResult, UniversalMachineModel]] = {}
    for row in rows:
        if not isinstance(row, dict):
            raise ExtractionError("LLM batch extraction contained a non-object chunk result")
        chunk_id = str(row.get("source_chunk_id") or "")
        if chunk_id not in expected or chunk_id in seen:
            raise ExtractionError("LLM batch extraction returned an unknown or duplicate source_chunk_id")
        knowledge = row.get("knowledge")
        if not isinstance(knowledge, dict):
            raise ExtractionError(f"LLM batch extraction missing knowledge object for {chunk_id}")
        try:
            for key in ("components", "relationships", "procedures", "entities", "relations", "ports", "quantities", "states", "events", "behaviors", "constraints"):
                if isinstance(knowledge.get(key), list):
                    knowledge[key] = [normalize_payload(item, kind=key[:-1] if key.endswith("s") else key) if isinstance(item, dict) else item for item in knowledge[key]]
            result = MachineKnowledgeExtractionResult.model_validate(knowledge)
        except ValueError as exc:
            raise ExtractionError(f"LLM batch extraction schema validation failed for {chunk_id}: {exc}") from exc
        legacy = _legacy_result(result)
        model = _universal_model_from_result(result) if _has_universal_facts(result) else _legacy_model(result)
        out[chunk_id] = (legacy, model)
        seen.add(chunk_id)

    missing = [chunk_id for chunk_id in expected if chunk_id not in seen]
    if missing:
        raise ExtractionError(f"LLM batch extraction omitted {len(missing)} source chunks")
    return out


def _legacy_result(result: MachineKnowledgeExtractionResult) -> ExtractionResult:
    return ExtractionResult(
        components=result.components,
        relationships=result.relationships,
        procedures=result.procedures,
    )


def extract_chunk_knowledge(content: str) -> tuple[ExtractionResult, UniversalMachineModel]:
    """Extract legacy Product Brain rows and universal facts in one provider call."""
    result = _extract_result(content)
    legacy = _legacy_result(result)
    if _has_universal_facts(result):
        return legacy, _universal_model_from_result(result)
    return legacy, _legacy_model(result)


def _has_universal_facts(result: MachineKnowledgeExtractionResult) -> bool:
    return any((
        result.entities, result.relations, result.ports, result.quantities,
        result.states, result.events, result.behaviors, result.constraints,
    ))


def extract_from_chunk_text(content: str) -> ExtractionResult:
    return extract_chunk_knowledge(content)[0]


def persist_extraction(
    session: Session,
    revision_id: str,
    source_chunk_id: str,
    result: ExtractionResult,
) -> None:
    """Write extracted components/relationships/procedures, linked back to their source chunk."""
    name_to_id: dict[str, str] = {}

    for comp in result.components:
        row = Component(
            revision_id=revision_id,
            name=comp.name,
            function=comp.function,
            location_description=comp.location_description,
            part_number=comp.part_number,
            source_chunk_id=source_chunk_id,
        )
        session.add(row)
        session.flush()  # get row.id without committing
        name_to_id[comp.name] = row.id

    for rel in result.relationships:
        from_id = name_to_id.get(rel.from_component)
        to_id = name_to_id.get(rel.to_component)
        if not (from_id and to_id):
            # Referenced a component not extracted in this same chunk (common —
            # relationships often span text extracted from other pages). Skip
            # rather than guess; a later cross-chunk linking pass can resolve
            # these by name within the same revision.
            continue
        try:
            relation_type = RelationType(rel.relation_type)
        except ValueError:
            continue
        session.add(
            ComponentRelationship(
                from_component_id=from_id,
                to_component_id=to_id,
                relation_type=relation_type,
                description=rel.description,
                source_chunk_id=source_chunk_id,
            )
        )

    for proc in result.procedures:
        try:
            procedure_type = ProcedureType(proc.procedure_type)
        except ValueError:
            continue
        session.add(
            Procedure(
                revision_id=revision_id,
                name=proc.name,
                procedure_type=procedure_type,
                steps=proc.steps,
                source_chunk_id=source_chunk_id,
            )
        )

    # The pipeline commits the complete extraction in one transaction. This
    # prevents retries from accumulating a partially extracted Product Brain.
    session.flush()


def extract_machine_knowledge_from_chunk(content: str) -> UniversalMachineModel:
    """Build a Phase 8A universal machine model from text evidence.

    This compatibility layer intentionally keeps the legacy extractor intact
    while exposing the universal representation expected by the Phase 8A docs.
    """
    return extract_chunk_knowledge(content)[1]


def _legacy_model(result: MachineKnowledgeExtractionResult) -> UniversalMachineModel:
    legacy = _legacy_result(result)
    model = UniversalMachineModel()
    for comp in legacy.components:
        evidence = [MachineEvidence(
            fact=f"Component {comp.name} extracted from manual text",
            source_type="text",
            confidence=0.7,
            extraction_method="legacy_component_extractor",
        )]
        model.entities.append(MachineEntity(
            id=f"entity:{comp.name.lower().replace(' ', '-')}",
            name=comp.name,
            entity_type="component",
            properties={
                "function": comp.function,
                "location_description": comp.location_description,
                "part_number": comp.part_number,
            },
            evidence=evidence,
        ))
    for rel in legacy.relationships:
        model.relations.append(MachineRelation(
            subject_id=f"entity:{rel.from_component.lower().replace(' ', '-')}",
            subject_name=rel.from_component,
            relation_type=rel.relation_type,
            object_id=f"entity:{rel.to_component.lower().replace(' ', '-')}",
            object_name=rel.to_component,
            description=rel.description,
            evidence=[MachineEvidence(
                fact=f"{rel.from_component} {rel.relation_type} {rel.to_component}",
                source_type="text",
                confidence=0.7,
                extraction_method="legacy_relationship_extractor",
            )],
        ))
    for proc in legacy.procedures:
        model.behaviors.append(MachineBehavior(
            id=f"behavior:{proc.name.lower().replace(' ', '-')}",
            subject_id="",
            subject_name=proc.name,
            description="Procedure: " + "; ".join(proc.steps),
            evidence=[MachineEvidence(
                fact=f"Procedure {proc.name} extracted",
                source_type="text",
                confidence=0.6,
                extraction_method="legacy_procedure_extractor",
            )],
        ))
    return model


def _universal_model_from_result(result: MachineKnowledgeExtractionResult) -> UniversalMachineModel:
    """Convert the provider-neutral extraction contract into typed primitives."""
    model = UniversalMachineModel()
    for item in result.entities:
        model.entities.append(MachineEntity.model_validate(item.model_dump()))
    for item in result.relations:
        model.relations.append(MachineRelation.model_validate(item.model_dump()))
    for item in result.ports:
        model.ports.append(MachinePort.model_validate(item))
    for item in result.quantities:
        model.quantities.append(MachineQuantity.model_validate(item))
    for item in result.states:
        model.states.append(MachineState.model_validate(item))
    for item in result.events:
        model.events.append(MachineEvent.model_validate(item))
    for item in result.behaviors:
        model.behaviors.append(MachineBehavior.model_validate(item))
    for item in result.constraints:
        model.constraints.append(MachineConstraint.model_validate(item))
    model.evidence.extend(result.evidence)
    return model


def persist_machine_knowledge(session: Session, revision_id: str | None, source_chunk_id: str | None, model: UniversalMachineModel) -> None:
    """Persist the universal machine model into project tables for later graph/RAG work."""
    for entity in model.entities:
        db_entity = MachineKnowledgeEntity(
            revision_id=revision_id,
            name=entity.name,
            entity_type=entity.entity_type,
            properties=entity.properties,
            ports=entity.ports,
            states=entity.states,
            source_chunk_id=source_chunk_id,
        )
        session.add(db_entity)
        session.flush()
        _persist_evidence(session, "entity", db_entity.id, entity.evidence)

    for rel in model.relations:
        db_rel = MachineKnowledgeRelation(
            revision_id=revision_id,
            subject_id=rel.subject_id,
            subject_name=rel.subject_name,
            relation_type=rel.relation_type,
            object_id=rel.object_id,
            object_name=rel.object_name,
            description=rel.description,
            source_chunk_id=source_chunk_id,
        )
        session.add(db_rel)
        session.flush()
        _persist_evidence(session, "relation", db_rel.id, rel.evidence)

    for behavior in model.behaviors:
        db_behavior = MachineKnowledgeBehavior(
            revision_id=revision_id,
            subject_id=behavior.subject_id,
            subject_name=behavior.subject_name,
            description=behavior.description,
            source_chunk_id=source_chunk_id,
        )
        session.add(db_behavior)
        session.flush()
        _persist_evidence(session, "behavior", db_behavior.id, behavior.evidence)

    for fact_type, fact_key, payload in model.all_facts():
        if fact_type == "behavior":
            continue  # Behaviors already have the dedicated legacy table above.
        session.add(MachineKnowledgeFact(
            revision_id=revision_id,
            fact_type=fact_type,
            fact_key=fact_key,
            payload=payload,
            source_chunk_id=source_chunk_id,
        ))
        _persist_evidence_dicts(session, fact_type, fact_key, payload.get("evidence", []))

    _persist_evidence(session, "model", source_chunk_id, model.evidence)

    session.flush()


def _persist_evidence(session: Session, item_type: str, item_id: str | None, evidence: list[MachineEvidence]) -> None:
    for ev in evidence:
        session.add(MachineKnowledgeEvidence(
            item_type=item_type,
            item_id=item_id,
            fact=ev.fact,
            source_document=ev.source_document,
            page=ev.page,
            chunk=ev.chunk,
            source_type=ev.source_type,
            location=ev.location,
            region=ev.region,
            confidence=ev.confidence,
            extraction_method=ev.extraction_method,
            claim_status=ev.claim_status,
            evidence_metadata=ev.metadata,
        ))


def _persist_evidence_dicts(session: Session, item_type: str, item_id: str, evidence: list[dict]) -> None:
    for item in evidence:
        session.add(MachineKnowledgeEvidence(
            item_type=item_type,
            item_id=item_id,
            fact=item.get("fact", f"{item_type}:{item_id}"),
            source_document=item.get("source_document"),
            page=item.get("page"),
            chunk=item.get("chunk"),
            source_type=item.get("source_type"),
            location=item.get("location"),
            region=item.get("region"),
            confidence=item.get("confidence", 0.0),
            extraction_method=item.get("extraction_method"),
            claim_status=item.get("claim_status", "observed"),
            evidence_metadata=item.get("metadata", {}),
        ))


def extract_machine_knowledge(content: str) -> MachineKnowledgeExtractionResult:
    """Structured result shape that matches the Phase 8A schema contract."""
    result = _extract_result(content)
    if _has_universal_facts(result):
        return result

    legacy = _legacy_result(result)
    for comp in legacy.components:
        result.entities.append(UniversalEntity(
            id=f"entity:{comp.name.lower().replace(' ', '-')}",
            name=comp.name,
            entity_type="component",
            properties={
                "function": comp.function,
                "location_description": comp.location_description,
                "part_number": comp.part_number,
            },
            ports=[],
            states=[],
        ))
    for rel in legacy.relationships:
        result.relations.append(UniversalRelation(
            subject_id=f"entity:{rel.from_component.lower().replace(' ', '-')}",
            subject_name=rel.from_component,
            relation_type=rel.relation_type,
            object_id=f"entity:{rel.to_component.lower().replace(' ', '-')}",
            object_name=rel.to_component,
            description=rel.description,
        ))
    return result
